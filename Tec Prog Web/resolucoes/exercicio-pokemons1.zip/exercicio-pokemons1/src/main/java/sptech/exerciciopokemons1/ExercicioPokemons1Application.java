package sptech.exerciciopokemons1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioPokemons1Application {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioPokemons1Application.class, args);
	}

}
