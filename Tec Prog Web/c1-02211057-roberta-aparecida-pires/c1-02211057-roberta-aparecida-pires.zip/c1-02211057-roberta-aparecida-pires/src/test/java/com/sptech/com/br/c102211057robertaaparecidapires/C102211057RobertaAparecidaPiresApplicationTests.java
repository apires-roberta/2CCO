package com.sptech.com.br.c102211057robertaaparecidapires;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C102211057RobertaAparecidaPiresApplicationTests {

	@Test
	void contextLoads() {
	}

}
