package com.sptech.com.br.c102211057robertaaparecidapires;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C102211057RobertaAparecidaPiresApplication {

	public static void main(String[] args) {
		SpringApplication.run(C102211057RobertaAparecidaPiresApplication.class, args);
	}

}
