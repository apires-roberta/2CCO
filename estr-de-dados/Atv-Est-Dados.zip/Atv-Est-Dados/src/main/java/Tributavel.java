public interface Tributavel {
    public Double getValorTributo();

}
