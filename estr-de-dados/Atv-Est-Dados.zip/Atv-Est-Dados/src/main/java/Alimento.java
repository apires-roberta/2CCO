public class Alimento extends Produto{

    //Atributos
    private Integer qtdVitamina;

    //Construtor
    public Alimento(Integer codigo, String descricao, Double preco, Integer qtditamina) {
        super(codigo, descricao, preco);
        this.qtdVitamina = qtditamina;
    }

    //Metodos
    @Override
    public String toString() {
        return "Alimento{" +
                "qtditamina=" + qtdVitamina +
                "} " + super.toString();
    }

    @Override
    public Double getValorTributo() {
        Double valor = getPreco() * 0.15;
        return valor;
    }
}
