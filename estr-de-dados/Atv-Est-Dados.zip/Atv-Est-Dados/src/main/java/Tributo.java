import java.util.ArrayList;

public class Tributo {
    private ArrayList<Tributavel> listTrib;

    public Tributo(ArrayList<Tributavel> listaTrib) {
        this.listTrib = new ArrayList<>();
    }

    public void adicionaTributavel(Tributavel t) {
        listTrib.add(t);
    }

    public Double calculaTotalTributo() {
        Double valor = 0.0;
        for (Tributavel t : listTrib) {
            valor += t.getValorTributo();
        }
        return valor;
    }
}
