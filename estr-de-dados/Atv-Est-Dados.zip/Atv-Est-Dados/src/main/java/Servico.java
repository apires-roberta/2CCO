public class Servico implements Tributavel{

    //Atributo
    private String descricao;
    private Double preco;

    //Construtor
    public Servico(String descricao, Double preco) {
        this.descricao = descricao;
        this.preco = preco;
    }

    //Metodos
    @Override
    public Double getValorTributo() {
        Double valor = getPreco() * 0.12;
        return valor;
    }

    @Override
    public String toString() {
        return "Servico{" +
                "descricao='" + descricao + '\'' +
                ", preco=" + preco +
                '}';
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }
}
