import java.util.ArrayList;
import java.util.Arrays;

public class TestaTributo {
    public static void main(String[] args) {
        Alimento alimento1 = new Alimento(111, "Alimento Saudavél", 4.50, 55);
        Perfume perfume1 = new Perfume(222,"Perfume", 30.50, "Cheirosa");
        Servico servico1 = new Servico("Caixa", 1200.0);
        Tributo tributo1 = new Tributo(new ArrayList<>());

        tributo1.adicionaTributavel(alimento1);
        tributo1.adicionaTributavel(perfume1);
        tributo1.adicionaTributavel(servico1);

        System.out.println(tributo1.calculaTotalTributo());
    }
}
