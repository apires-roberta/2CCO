public class Perfume extends Produto{

    //Atributos
    private String fragrancia;

    //Construtor

    public Perfume(Integer codigo, String descricao, Double preco, String fragrancia) {
        super(codigo, descricao, preco);
        this.fragrancia = fragrancia;
    }

    //Metodos


    @Override
    public String toString() {
        return "Perfume{" +
                "fragrancia='" + fragrancia + '\'' +
                "} " + super.toString();
    }

    @Override
    public Double getValorTributo() {
        Double valor = getPreco() * 0.27;
        return valor;
    }
}
