public class ListaObj <T>{
    private T[] vetor;
    private int nrpElem;

    public ListaObj(int tam) {
        vetor = (T[]) new Object[tam];
        nrpElem = 0;
    }

    public void adiciona(T valorAdicionar) {
        if (nrpElem == vetor.length) {
            System.out.println("Lista cheia");
        } else {
            vetor[nrpElem++] = valorAdicionar;
        }
    }

    public void exibe() {
        for (int i = 0; i < nrpElem; i++) {
            System.out.println(vetor[i]);
        }
    }

    public int busca(T valorBuscar) {
        for (int i = 0; i < vetor.length; i++) {
            if (valorBuscar.equals(vetor[i])) {
                return i;
            }
        }
        return -1;
    }

    public boolean removePeloIndice(int indice) {
        if (indice < 0 || indice >= nrpElem) {
            System.out.println("Valor inválido");
            return false;
        }

        for (int i = indice; i < nrpElem - 1; i++) {
            vetor[i] = vetor[i+1];

        }
        nrpElem--;
        return true;
    }

    public void buscaPeloIndice(int indice) {
        for (int i = 0; i < nrpElem; i++) {
            if (i == indice)
            {
                System.out.println(vetor[indice]);
                return;
            }
        }
        System.out.println("Valor inválido");
    }



    public boolean removeElemento(T elementoRemover){
        return removePeloIndice(busca(elementoRemover));
    }

    public boolean substitui(T valorAntigo, T valorNovo) {
        for (int i = 0; i < nrpElem; i++) {
            if (valorAntigo == vetor[i]) {
                vetor[i] = valorNovo;
                return true;
            }
        }
        return false;
    }

    public int contaOcorrencias(T arg){
        int contador = 0;
        for (int i = 0; i <nrpElem; i++) {
            if (arg == vetor[i]) {
                contador++;
            }
        }
        return contador;
    }

    public boolean adicionaNoInicio(T valor){
        if (nrpElem == vetor.length ) {
            System.out.println("Lista cheia");
            return false;
        }
        for (int i = nrpElem-1; i >=0 ; i--){
            vetor[i+1] = vetor[i];
        }
        vetor[0] = valor;
        nrpElem++;
        return true;
    }


    public T[] getVetor() {
        return vetor;
    }

    public void setVetor(T[] vetor) {
        this.vetor = vetor;
    }

    public int getTamanho() {
        return nrpElem;
    }

    public T getElemento(int indice) {
        if (indice < 0 || indice >= nrpElem) {
            return null;
        } else {
            return vetor[indice];
        }
    }

    public void limpa() {
        nrpElem = 0;
    }

    public void setNrpElem(int nrpElem) {
        this.nrpElem = nrpElem;
    }
}
