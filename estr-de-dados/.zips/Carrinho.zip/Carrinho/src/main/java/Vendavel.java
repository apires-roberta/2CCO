public interface Vendavel {
    double getValorVenda();
}
