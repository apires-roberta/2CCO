import java.util.ArrayList;

public class Carrinho {

    private ArrayList<Vendavel> cart;

    public void adicionarVenda(Vendavel t) {
        cart.add(t);
    }

    public Double calculaTotalVenda() {
        Double valor = 0.0;
        for (Vendavel t : cart) {
            valor += t.getValorVenda();
        }
        return valor;
    }

    public void exibeItensCarrinho(){
        for (Vendavel t : cart) {
            System.out.println(t);
        }
    }
}
