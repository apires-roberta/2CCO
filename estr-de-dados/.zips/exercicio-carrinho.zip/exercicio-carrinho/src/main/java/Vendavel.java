public interface Vendavel {
    public Double getValorVenda();
}
