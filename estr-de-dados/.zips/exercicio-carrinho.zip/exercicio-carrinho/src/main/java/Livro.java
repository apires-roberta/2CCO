public class Livro extends Produto{

    //Atributos
    private String autor;
    private String isbn;

    //Construtor
    public Livro(Integer codigo, String nome, Double precoCusto, String autor, String isbn) {
        super(codigo, nome, precoCusto);
        this.autor = autor;
        this.isbn = isbn;
    }

    public Livro(Integer codigo, String nome, Double precoCusto) {
        super(codigo, nome, precoCusto);
    }

    //Metodos
    @Override
    public Double getValorVenda() {
        Double valor = getPrecoCusto() * 0.1;
        return valor;
    }

    @Override
    public String toString() {
        return "Livro{" +
                "autor='" + autor + '\'' +
                ", isbn='" + isbn + '\'' +
                "} " + super.toString();
    }
}
