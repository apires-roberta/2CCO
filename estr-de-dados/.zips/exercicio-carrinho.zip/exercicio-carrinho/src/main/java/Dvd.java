public class Dvd extends Produto{

    //Atributos
    private String gravadora;

    //Construtor
    public Dvd(Integer codigo, String nome, Double precoCusto, String gravadora) {
        super(codigo, nome, precoCusto);
        this.gravadora = gravadora;
    }

    //Metodos
    @Override
    public Double getValorVenda() {
        Double valor = getPrecoCusto() * 0.2;
        return valor;
    }

    @Override
    public String toString() {
        return "Dvd{" +
                "gravadora='" + gravadora + '\'' +
                "} " + super.toString();
    }


}
