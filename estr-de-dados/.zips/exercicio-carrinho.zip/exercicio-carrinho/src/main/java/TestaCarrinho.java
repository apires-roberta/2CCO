import java.util.Scanner;

public class TestaCarrinho {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        System.out.println("Escolha uma opção: \n" +
                "1. Adicionar livro \n" +
                "2. Adicionar DVD \n" +
                "3. Adicionar Servico \n" +
                "4. Exibir itens do carrinho \n" +
                "5. Exibir total de venda \n" +
                "6. Fim \n");
    }

    Integer valorUser = 0;
    
}
