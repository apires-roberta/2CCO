public interface Bonus {

    public Double getValorBonus();
}
