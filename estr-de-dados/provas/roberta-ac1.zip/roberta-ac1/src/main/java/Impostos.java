public interface Impostos {
    public Double getValorImposto();
}
