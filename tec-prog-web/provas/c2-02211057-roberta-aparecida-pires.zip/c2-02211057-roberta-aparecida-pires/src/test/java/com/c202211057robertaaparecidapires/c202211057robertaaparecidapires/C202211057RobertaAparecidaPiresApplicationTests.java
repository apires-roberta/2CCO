package com.c202211057robertaaparecidapires.c202211057robertaaparecidapires;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C202211057RobertaAparecidaPiresApplicationTests {

	@Test
	void contextLoads() {
	}

}
