package com.c202211057robertaaparecidapires.c202211057robertaaparecidapires;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C202211057RobertaAparecidaPiresApplication {

	public static void main(String[] args) {
		SpringApplication.run(C202211057RobertaAparecidaPiresApplication.class, args);
	}

}
