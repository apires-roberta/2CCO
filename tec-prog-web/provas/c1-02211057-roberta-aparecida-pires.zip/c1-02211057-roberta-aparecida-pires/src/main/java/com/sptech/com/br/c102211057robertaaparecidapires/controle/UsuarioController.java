package com.sptech.com.br.c102211057robertaaparecidapires.controle;

import com.sptech.com.br.c102211057robertaaparecidapires.entidade.Usuario;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private List<Usuario> usuarios = new ArrayList<>();

    @GetMapping
    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    @PostMapping
    public String postUsuario(@RequestBody Usuario novoUsuario) {
        usuarios.add(novoUsuario);
        return "Usuário " + novoUsuario.getNome() + " cadastrado com sucesso";
    }

    @PostMapping("/autenticacao/{usuario}/{senha}")
    public String autenticandoUsuario(@PathVariable String usuario,
                                      @PathVariable String senha) {
        if (getUsuarios().equals(usuario) && getUsuarios().equals(senha)) {
            return "Usuário " + usuario + " agora está autenticado";
        } else {
            return "Usuário " + usuario + " não encontrado";
        }
    }

    @DeleteMapping("/autenticacao/{usuario}")
    public String delUsuario(@PathVariable String usuario) {
        if (usuario.isEmpty()) {
            return "Usuário " + usuario + " não encontrado";
        } else if (getUsuarios().equals(usuario)) {
            getUsuarios().remove(usuario);
            return "Logoff do usuário " + usuario + " concluído";
        } else {
            return "Usuário " + usuario + " NÃO está autenticado";
        }

    }


}
