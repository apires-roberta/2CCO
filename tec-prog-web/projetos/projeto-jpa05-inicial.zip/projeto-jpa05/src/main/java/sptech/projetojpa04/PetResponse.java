package sptech.projetojpa04;

public class PetResponse {

    private String nome;

    public PetResponse(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
