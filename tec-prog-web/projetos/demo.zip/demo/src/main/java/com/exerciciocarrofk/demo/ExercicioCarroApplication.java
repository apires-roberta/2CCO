package com.exerciciocarrofk.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioCarroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioCarroApplication.class, args);
	}

}
