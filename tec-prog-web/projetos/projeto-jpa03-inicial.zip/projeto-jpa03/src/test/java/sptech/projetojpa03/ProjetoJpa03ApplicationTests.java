package sptech.projetojpa03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoJpa03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
